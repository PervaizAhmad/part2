import React from "react";
import Paper from "./Paper/Paper";

class Papers extends React.Component {

  constructor(props) {
    super(props)
    this.state = { results: [] }
  }

  componentDidMount() {
    let url = "http://unn-w18014333.newnumyspace.co.uk/kf6012/coursework/part1/api/papers"
    this.fetchData(url)
  }

  componentDidUpdate(prevProps) {
    console.log('award - ' + this.props.award)
  }

  fetchData = (url) => {
    if (this.props.authorId !== undefined) {
      url += "?author_id=" + this.props.authorId
    } else if (this.props.award !== undefined && this.props.award !== "") {
      url += "?award=" + this.props.award
    }

    fetch(url)
      .then((response) => {
        return response.json()
      })
      .then((data) => {
        if (this.props.randonPaper) {
          const randonPaperId = Math.floor(Math.random() * data.results.length) + 1
          this.setState({ results: [data.results[randonPaperId]] })
        } else {
          this.setState({ results: data.results })
        }
      })
      .catch((err) => {
        console.log("something went wrong ", err)
      });
  }

  /**
   * If the award props is 'all', this will return
   * the paper if it has an award_id.
   * 
   * If the award props is 'none', this will return
   * the paper if it doesn't have an award_id.
   * 
   * If the award props is nether, every paper is
   * returned.
   * 
   * @param {any} paper The paper to be checked.
   * @returns           Whether the paper should be displayed
   */
  /*filterByAward = (paper) => {
    if (this.props.award === 'none') {
      return paper.award_type_name === null
    } else if (this.props.award === 'all') {
      return paper.award_type_name !== null
    } else return true
  }*/

  render() {
    console.log(this.props.award)
    let noData = ''

    if (this.state.results.length === 0) {
      noData = 'No Data'
    }

    // const filteredResults = this.state.results.filter(this.filterByAward)

    return (
      <div>
        {noData}
        {/*filteredResults*/this.state.results.map((paper, i) => (<Paper key={i} paper={paper} />))}
        {/* <p key={i}>{film.paper_title}</p> */}
      </div>
    )
  }
}

export default Papers;