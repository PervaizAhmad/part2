import React from "react";
import Papers from "../../Papers/Papers";

class PapersPage extends React.Component {
    constructor(props) {
        super(props)
        this.state = {
            award: ""
        }
    }

    componentDidMount() {
        let url = "http://unn-w18014333.newnumyspace.co.uk/kf6012/coursework/part1/api/papers?award=all"

        fetch(url)
            .then((response) => {
                return response.json()
            })
            .then((data) => {
                // Getting all awards and award_ids from API
                // and storing it in an array
                let arr = []
                data.results.forEach(p => {
                    let diff = true;
                    arr.forEach(award => {
                        if (p.award_type_name === award) {
                            diff = false;
                        }
                    })
                    if (diff) {
                        arr.push(p.award_type_id, p.award_type_name)
                    }
                })
            })
            .catch((err) => {
                console.log("something went wrong ", err)
            });
    }

    handleLanguageSelect = (e) => {
        this.setState({ award: e.target.value })
    }

    render() {
        return (
            <div>
                <label>
                    Awards:
                    <select value={this.state.language} onChange={this.handleLanguageSelect}>
                        <option value="">All papers</option>
                        <option value="none">No awards</option>
                        <option value="all">All awards</option>
                        <option value="">Custom Select</option>
                    </select>
                </label>
                <Papers award={this.state.award} />
            </div>
        )
    }
}

export default PapersPage;