import React from "react";

class ReadingList extends React.Component {

  constructor(props) {
    super(props)
  }

  render() {
    return (
      <p>ReadingList</p>
    )
  }
}

export default ReadingList;